/*
 * Jitsi, the OpenSource Java VoIP and Instant Messaging client.
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
#include "IWeakReferenceSource.h"

EXTERN_C const GUID DECLSPEC_SELECTANY IID_IWeakReferenceSource
    = { 0xcb401dba, 0xadbe, 0x4d7a, { 0x82, 0x75, 0xe2, 0xc4, 0xb7, 0xf9, 0x5c, 0xe0 } };
