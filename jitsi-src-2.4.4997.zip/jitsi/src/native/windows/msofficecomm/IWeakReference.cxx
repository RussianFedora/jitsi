/*
 * Jitsi, the OpenSource Java VoIP and Instant Messaging client.
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
#include "IWeakReference.h"

EXTERN_C const GUID DECLSPEC_SELECTANY IID_IWeakReference
    = { 0xc59ff8e2, 0xf328, 0x4c93, { 0xa6, 0x2d, 0xe5, 0x03, 0x27, 0x20, 0x0a, 0x4a } };
